
public class shuffler {
	public static void main(String[] args) {
		int[]array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		selectionShuffle(array);
		for(int i = 0; i < array.length; i++){
			System.out.print(array[i] + " ");
		}
	}

	public static void selectionShuffle(int[] values) {
		int[] shuffled = new int[values.length];
		for (int i = 0; i < values.length; i++) {
			int x = (int) (Math.random() * (values.length));
			if (values[x] == -1) {
				i -= 1;
			} else {
				shuffled[i] = values[x];
				values[x] = -1;
			}
		}
		for (int v = 0; v < values.length; v++) {
			values[v] = shuffled[v];
		}
	}
}
