package elevens;

import static org.junit.Assert.*;

import org.junit.Test;

public class CardTest {

	@Test
	public void testCard() {
		Card card = new Card("Jack", "Spades", -1);
		assertEquals(card, card);
	}

	@Test
	public void testSuit() {
		Card card = new Card("Jack", "Spades", -1);
		assertEquals(true, card.suit().equals("Spades"));
	}

	@Test
	public void testRank() {
		Card card = new Card("Jack", "Spades", -1);
		assertEquals(true, card.rank().equals("Jack"));
	}

	@Test
	public void testPointValue() {
		Card card = new Card("Jack", "Spades", -1);
		assertEquals(true, card.pointValue() == -1);
	}

	@Test
	public void testMatches() {
		Card card = new Card("Jack", "Spades", -1);
		Card card1 = new Card("Jack", "Spades", -1);
		assertEquals(true, card.matches(card1));
	}

	@Test
	public void testToString() {
		Card card = new Card("Jack", "Spades", -1);
		assertEquals(card.toString(), "Jack of Spades (point value = -1)");
	}

}
