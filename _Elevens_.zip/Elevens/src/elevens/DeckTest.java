package elevens;

import static org.junit.Assert.*;

import org.junit.Test;

public class DeckTest {

	@Test
	public void testDeck() {
		String[] ranks = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
		String[] suits = {"Spades", "Hearts", "Clubs", "Diamonds"};
		int[] values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -1, -2, -3};
		Deck deck = new Deck(ranks, suits, values);
		assertEquals(deck.size(), 52);
	}
	@Test
	public void testDeck1() {
		String[] ranks = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
		String[] suits = {"Spades", "Hearts", "Clubs", "Diamonds", "Zoboomafoo"};
		int[] values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -1, -2, -3};
		Deck deck = new Deck(ranks, suits, values);
		assertEquals(deck.size(), 65);
	}
	@Test
	public void testEmpty(){
		String[] ranks = {};
		String[] suits = {};
		int[] values = {};
		Deck deck = new Deck(ranks, suits, values);
		assertEquals(deck.isEmpty(), true);
	}
	@Test
	public void testEmpty1(){
		String[] ranks = {"hi"};
		String[] suits = {"hi"};
		int[] values = {1};
		Deck deck = new Deck(ranks, suits, values);
		assertEquals(deck.isEmpty(), false);
	}

}
