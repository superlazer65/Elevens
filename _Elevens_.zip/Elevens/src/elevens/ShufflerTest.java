package elevens;

import static org.junit.Assert.*;

import org.junit.Test;

public class ShufflerTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
